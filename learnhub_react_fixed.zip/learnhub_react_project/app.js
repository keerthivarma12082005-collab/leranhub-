const express = require('express');
const cors    = require('cors');
const connectDB = require('./connection');

const courseRoutes     = require('./routes/courseRoutes');
const enrollmentRoutes = require('./routes/enrollmentRoutes');
const userRoutes       = require('./routes/userRoutes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Connect DB
connectDB();

// Routes
app.use('/courses',     courseRoutes);
app.use('/enrollments', enrollmentRoutes);
app.use('/users',       userRoutes);

// Health check
app.get('/', (req, res) => res.json({ message: 'LearnHub API is running 🎓' }));

const PORT = process.env.PORT || 8002;
app.listen(PORT, () => console.log(`LearnHub server running on port ${PORT}`));
