# 🎓 LearnHub – Online Course Marketplace

A full-stack course marketplace built with **Node.js + Express + MongoDB** (backend) and **vanilla HTML/CSS/JS** (frontend).

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Start MongoDB
Make sure MongoDB is running locally (default port 27017).

### 3. Seed the database with 12 sample courses *(new!)*
```bash
node seed.js
```
This populates your DB with courses across 5 categories:  
Web Development · Data Science · Design · Business · Marketing

> **No MongoDB?** No problem — the backend automatically serves 12 built-in sample courses when the database is empty, so the UI is never blank.

### 4. Start the server
```bash
npm start
# or
node app.js
```
Server runs on **http://localhost:8002**

### 5. Open the frontend
Open `frontend/home.html` in your browser (or use Live Server in VS Code).

---

## Project Structure

```
onlinemarket_course/
├── app.js                  # Express entry point
├── connection.js           # MongoDB connection
├── seed.js                 # ← NEW: run once to populate courses
├── models/
│   ├── Course.js
│   ├── User.js
│   └── Enrollment.js
├── controllers/
│   ├── courseController.js  # ← Updated: fallback sample courses
│   ├── userController.js
│   └── enrollmentController.js
├── routes/
│   ├── courseRoutes.js
│   ├── userRoutes.js
│   └── enrollmentRoutes.js
└── frontend/
    ├── home.html
    ├── courses.html        # Responsive course cards grid
    ├── enrollments.html
    ├── login.html
    ├── signup.html
    ├── script.js
    ├── enrollments.js
    └── style.css
```

---

## Sample Courses Included

| # | Title | Category | Duration |
|---|-------|----------|----------|
| 1 | Full-Stack Web Development Bootcamp | Web Development | 48 hrs |
| 2 | React & Next.js – From Zero to Pro | Web Development | 32 hrs |
| 3 | Node.js REST API Masterclass | Web Development | 20 hrs |
| 4 | Python for Data Science & ML | Data Science | 40 hrs |
| 5 | SQL & Database Analytics | Data Science | 18 hrs |
| 6 | Deep Learning with TensorFlow | Data Science | 35 hrs |
| 7 | UI/UX Design with Figma | Design | 22 hrs |
| 8 | Motion Design & After Effects | Design | 25 hrs |
| 9 | Product Management Fundamentals | Business | 16 hrs |
| 10 | Financial Modelling & Valuation | Business | 28 hrs |
| 11 | Digital Marketing & SEO Masterclass | Marketing | 24 hrs |
| 12 | Content Marketing & Brand Storytelling | Marketing | 14 hrs |

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/courses` | Get all courses |
| GET | `/courses/:id` | Get course by ID |
| POST | `/courses` | Create a course |
| PUT | `/courses/:id` | Update a course |
| DELETE | `/courses/:id` | Delete a course |
| GET | `/users` | Get all users |
| POST | `/users` | Create a user |
| GET | `/enrollments` | Get all enrollments |
| POST | `/enrollments` | Create enrollment |
