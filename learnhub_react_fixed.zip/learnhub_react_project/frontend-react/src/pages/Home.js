import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';

export default function Home() {
  const navigate = useNavigate();
  return (
    <div className="home-hero">
      <div className="home-content">
        <div className="home-eyebrow">
          <span>🎓</span> New Courses Added Every Week
        </div>
        <h1 className="home-title">
          Learn from the<br />
          <span className="gradient-text">Best Instructors</span><br />
          Worldwide
        </h1>
        <p className="home-subtitle">
          Discover thousands of courses at unbeatable prices.<br />
          Learn at your pace, earn certificates, grow your career.
        </p>
        <div className="home-actions">
          <button className="btn btn-primary" onClick={() => navigate('/signup')}>Get Started Free</button>
          <button className="btn btn-ghost" onClick={() => navigate('/login')}>Sign In →</button>
        </div>
        <div className="home-stats">
          <div className="stat-item">
            <div className="stat-num">500+</div>
            <div className="stat-label">Courses</div>
          </div>
          <div className="stat-item">
            <div className="stat-num">50K+</div>
            <div className="stat-label">Learners</div>
          </div>
          <div className="stat-item">
            <div className="stat-num">4.9★</div>
            <div className="stat-label">Avg Rating</div>
          </div>
        </div>
      </div>
    </div>
  );
}
