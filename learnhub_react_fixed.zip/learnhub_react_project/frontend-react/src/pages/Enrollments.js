import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { useToast } from '../ToastContext';
import './Enrollments.css';

const API = 'http://localhost:8002';

function getCatClass(title) {
  if (!title) return 'cat-other';
  const t = title.toLowerCase();
  if (t.includes('web') || t.includes('javascript') || t.includes('html') || t.includes('react')) return 'cat-web';
  if (t.includes('data') || t.includes('python') || t.includes('machine') || t.includes('ai')) return 'cat-data';
  if (t.includes('design') || t.includes('ui') || t.includes('ux') || t.includes('figma')) return 'cat-design';
  if (t.includes('business') || t.includes('management') || t.includes('finance')) return 'cat-biz';
  if (t.includes('market')) return 'cat-mkt';
  return 'cat-other';
}

export default function Enrollments() {
  const [mine, setMine] = useState([]);
  const [coursesMap, setCoursesMap] = useState({});
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const showToast = useToast();
  const user = useMemo(() => JSON.parse(localStorage.getItem('lh_user') || 'null'), []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [eRes, cRes] = await Promise.all([
        fetch(`${API}/enrollments`),
        fetch(`${API}/courses`)
      ]);
      const enrollments = await eRes.json();
      const courses = await cRes.json();
      const map = {};
      courses.forEach(c => { map[c._id] = c; });
      setCoursesMap(map);
      setMine(enrollments.filter(e => e.learnerName === user?.name));
    } catch {
      showToast('Could not load enrollments. Is the backend running?', 'error');
    }
    setLoading(false);
  }, [user?.name, showToast]);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    load();
  }, [navigate, load, user]);

  async function updateProgress(id, current) {
    const newProgress = Math.min(current + 10, 100);
    try {
      await fetch(`${API}/enrollments/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ progress: newProgress })
      });
      if (newProgress >= 100) showToast('🎉 Course completed! Congratulations!', 'success');
      else showToast(`Progress updated to ${newProgress}%`, 'info');
      load();
    } catch { showToast('Could not update progress.', 'error'); }
  }

  async function removeEnrollment(id) {
    try {
      await fetch(`${API}/enrollments/${id}`, { method: 'DELETE' });
      showToast('Enrollment removed.', 'success');
      load();
    } catch { showToast('Could not remove enrollment.', 'error'); }
  }

  const totalProgress = mine.reduce((s, e) => s + Math.min(e.progress || 0, 100), 0);
  const avg = mine.length ? Math.round(totalProgress / mine.length) : 0;
  const completed = mine.filter(e => (e.progress || 0) >= 100).length;

  return (
    <>
      <Navbar />
      <div className="page-header">
        <div className="page-header-left">
          <h1>My Enrollments</h1>
          <p>Track your learning progress</p>
        </div>
        <button className="btn btn-ghost" style={{ width: 'auto' }} onClick={() => navigate('/courses')}>
          ← Browse Courses
        </button>
      </div>

      <div className="cart-layout">
        <div id="enrollmentsContainer">
          {loading ? (
            <div className="spinner-wrap"><div className="spinner"></div></div>
          ) : !mine.length ? (
            <div className="empty-state">
              <div className="empty-icon">🎓</div>
              <h2>No enrollments yet</h2>
              <p>You haven't enrolled in any courses yet.</p>
              <button className="btn btn-primary" style={{ width: 'auto', margin: '0 auto' }} onClick={() => navigate('/courses')}>
                Browse Courses
              </button>
            </div>
          ) : mine.map((item, i) => {
            const prog = Math.min(item.progress || 0, 100);
            const course = coursesMap[item.courseId];
            const title = course ? course.courseTitle : `Course ID: ${item.courseId}`;
            const instructor = course ? course.instructorName : '—';
            const isComplete = prog >= 100;
            return (
              <div className="cart-card fade-up" key={item._id} style={{ animationDelay: `${Math.min(i * 0.06, 0.4)}s` }}>
                <div className={`cart-card-icon ${getCatClass(title)}`}>📚</div>
                <div className="cart-card-info">
                  <h3>{title}</h3>
                  <div className="price">👤 {item.learnerName} &nbsp;·&nbsp; 🏫 {instructor}</div>
                </div>
                <div className="progress-wrap">
                  <div className="progress-label">
                    <span>{isComplete ? '✅ Completed' : 'Progress'}</span>
                    <span style={{ color: isComplete ? 'var(--success)' : 'var(--primary-light)' }}>{prog}%</span>
                  </div>
                  <div className="progress-bar-bg">
                    <div className={`progress-bar-fill ${isComplete ? 'complete' : ''}`} style={{ width: `${prog}%` }}></div>
                  </div>
                </div>
                <div className="enroll-actions">
                  <button className="btn btn-primary btn-sm" onClick={() => updateProgress(item._id, prog)}>▶ Continue</button>
                  <button className="btn btn-danger btn-sm" onClick={() => removeEnrollment(item._id)}>🗑</button>
                </div>
              </div>
            );
          })}
        </div>

        {mine.length > 0 && (
          <div className="cart-summary">
            <h3>Learning Summary</h3>
            <div className="summary-row">
              <span>Total Enrolled</span><span>{mine.length}</span>
            </div>
            <div className="summary-row">
              <span>Avg Progress</span><span style={{ color: 'var(--success)' }}>{avg}%</span>
            </div>
            <div className="summary-row total">
              <span>Completed</span><span className="amount">{completed}</span>
            </div>
            <button className="btn btn-success" style={{ width: '100%', marginTop: 20 }} onClick={() => navigate('/courses')}>
              📚 Explore More Courses
            </button>
          </div>
        )}
      </div>
    </>
  );
}
