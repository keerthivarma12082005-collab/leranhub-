import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../ToastContext';
import './Auth.css';

const API = 'http://localhost:8002';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const showToast = useToast();

  async function handleLogin() {
    if (!email || !password) { showToast('Please fill in all fields.', 'error'); return; }
    setLoading(true);
    try {
      const res = await fetch(`${API}/users`);
      const users = await res.json();
      const user = users.find(u => u.email === email);
      if (user) {
        localStorage.setItem('lh_user', JSON.stringify(user));
        showToast(`Welcome back, ${user.name}!`, 'success');
        setTimeout(() => navigate('/courses'), 900);
      } else {
        showToast('No account found with that email.', 'error');
        setLoading(false);
      }
    } catch {
      showToast('Server unreachable. Is the backend running?', 'error');
      setLoading(false);
    }
  }

  return (
    <div className="auth-wrapper">
      <div className="auth-brand">
        <div className="auth-brand-logo">
          <div className="logo-mark-lg">🎓</div>
          <h1><span className="brand-v">Learn</span>Hub</h1>
        </div>
        <p className="auth-brand-tagline">Welcome back! Thousands of courses are waiting just for you.</p>
        <div className="auth-brand-features">
          <div className="feature-pill"><span className="pill-icon">📚</span> Pick up where you left off</div>
          <div className="feature-pill"><span className="pill-icon">📈</span> Track all your progress</div>
          <div className="feature-pill"><span className="pill-icon">🏆</span> Access your certificates</div>
          <div className="feature-pill"><span className="pill-icon">🎁</span> Member-only flash sales</div>
        </div>
      </div>
      <div className="auth-form-side">
        <div className="auth-form-box">
          <h2 className="form-title fade-up">Welcome back</h2>
          <p className="form-subtitle fade-up fade-up-1">
            New to LearnHub? <span className="link" onClick={() => navigate('/signup')}>Create an account</span>
          </p>
          <div className="field-group fade-up fade-up-2">
            <label>Email Address</label>
            <input type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleLogin()} />
          </div>
          <div className="field-group fade-up fade-up-3">
            <label>Password</label>
            <input type="password" placeholder="Enter your password" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleLogin()} />
          </div>
          <div style={{ marginTop: 24 }} className="fade-up fade-up-4">
            <button className="btn btn-primary" onClick={handleLogin} disabled={loading}>
              {loading ? 'Signing in…' : 'Sign In to LearnHub →'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
