import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../ToastContext';
import './Auth.css';

const API = 'http://localhost:8002';

export default function Signup() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const showToast = useToast();

  async function handleSignup() {
    if (!name || !email || !role) { showToast('Please fill in all fields.', 'error'); return; }
    setLoading(true);
    try {
      const res = await fetch(`${API}/users`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, role })
      });
      const data = await res.json();
      if (res.ok) {
        showToast('Account created! Redirecting…', 'success');
        setTimeout(() => navigate('/login'), 1200);
      } else {
        showToast(data.message || 'Signup failed.', 'error');
        setLoading(false);
      }
    } catch {
      showToast('Server unreachable. Is the backend running?', 'error');
      setLoading(false);
    }
  }

  return (
    <div className="auth-wrapper">
      <div className="auth-brand">
        <div className="auth-brand-logo">
          <div className="logo-mark-lg">🎓</div>
          <h1><span className="brand-v">Learn</span>Hub</h1>
        </div>
        <p className="auth-brand-tagline">Join thousands of learners who trust LearnHub for career growth.</p>
        <div className="auth-brand-features">
          <div className="feature-pill"><span className="pill-icon">🚀</span> Learn from industry experts</div>
          <div className="feature-pill"><span className="pill-icon">🔒</span> Secure &amp; encrypted platform</div>
          <div className="feature-pill"><span className="pill-icon">📜</span> Earn verified certificates</div>
          <div className="feature-pill"><span className="pill-icon">💎</span> Exclusive member discounts</div>
        </div>
      </div>
      <div className="auth-form-side">
        <div className="auth-form-box">
          <h2 className="form-title fade-up">Create account</h2>
          <p className="form-subtitle fade-up fade-up-1">
            Already have one? <span className="link" onClick={() => navigate('/login')}>Sign in here</span>
          </p>
          <div className="field-group fade-up fade-up-2">
            <label>Full Name</label>
            <input type="text" placeholder="e.g. Arjun Sharma" value={name} onChange={e => setName(e.target.value)} />
          </div>
          <div className="field-group fade-up fade-up-2">
            <label>Email Address</label>
            <input type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div className="field-group fade-up fade-up-3">
            <label>Role</label>
            <select value={role} onChange={e => setRole(e.target.value)}>
              <option value="">Select your role</option>
              <option value="learner">Learner</option>
              <option value="instructor">Instructor</option>
            </select>
          </div>
          <div style={{ marginTop: 24 }} className="fade-up fade-up-4">
            <button className="btn btn-primary" onClick={handleSignup} disabled={loading}>
              {loading ? 'Creating account…' : 'Create My Account →'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
