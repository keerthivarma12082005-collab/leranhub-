import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { useToast } from '../ToastContext';
import './Courses.css';

const API = 'http://localhost:8002';
const CATS = ['all', 'Web Development', 'Data Science', 'Design', 'Business', 'Marketing'];
const CAT_LABELS = { all: 'All', 'Web Development': 'Web Dev', 'Data Science': 'Data Science', Design: 'Design', Business: 'Business', Marketing: 'Marketing' };

function getCatEmoji(cat) {
  const map = { 'Web Development': '💻', 'Data Science': '📊', Design: '🎨', Business: '💼', Marketing: '📣' };
  return map[cat] || '📚';
}
function getCatClass(cat) {
  const map = { 'Web Development': 'cat-web', 'Data Science': 'cat-data', Design: 'cat-design', Business: 'cat-biz', Marketing: 'cat-mkt' };
  return map[cat] || 'cat-other';
}

export default function Courses() {
  const [all, setAll] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [activeCat, setActiveCat] = useState('all');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const showToast = useToast();

  useEffect(() => {
    const user = localStorage.getItem('lh_user');
    if (!user) { navigate('/login'); return; }
    fetch(`${API}/courses`)
      .then(r => r.json())
      .then(data => { setAll(data); setFiltered(data); setLoading(false); })
      .catch(() => { setLoading(false); showToast('Could not load courses. Is the backend running?', 'error'); });
  }, [navigate, showToast]);

  function filterBy(cat) {
    setActiveCat(cat);
    setFiltered(cat === 'all' ? all : all.filter(c => c.category === cat));
  }

  async function enrollCourse(courseId, courseTitle) {
    const user = JSON.parse(localStorage.getItem('lh_user'));
    if (!user) { navigate('/login'); return; }
    try {
      const res = await fetch(`${API}/enrollments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ learnerName: user.name, courseId, progress: 0 })
      });
      const data = await res.json();
      if (res.ok) showToast(`Enrolled in "${courseTitle}"! 🎉`, 'success');
      else showToast(data.message || 'Enrollment failed.', 'error');
    } catch {
      showToast('Could not enroll. Is the backend running?', 'error');
    }
  }

  return (
    <>
      <Navbar />
      <div className="page-header">
        <div className="page-header-left">
          <h1>All Courses</h1>
          <p>Browse our full catalogue of expert-led courses</p>
        </div>
        <button className="btn btn-primary" style={{ width: 'auto' }} onClick={() => navigate('/enrollments')}>
          📋 My Enrollments
        </button>
      </div>

      <div className="filter-bar">
        {CATS.map(cat => (
          <button key={cat} className={`filter-btn ${activeCat === cat ? 'active' : ''}`} onClick={() => filterBy(cat)}>
            {CAT_LABELS[cat]}
          </button>
        ))}
      </div>

      <div className="products-section">
        <div id="coursesContainer">
          {loading ? (
            <div className="spinner-wrap"><div className="spinner"></div></div>
          ) : !filtered.length ? (
            <div className="empty-state">
              <div className="empty-icon">📭</div>
              <h2>No courses in this category</h2>
              <p>Try another filter or check back soon!</p>
            </div>
          ) : filtered.map((course, i) => (
            <div className="card fade-up" key={course._id} style={{ animationDelay: `${Math.min(i * 0.05, 0.4)}s` }}>
              <div className={`card-banner ${getCatClass(course.category)}`}>
                <div className="card-banner-inner">
                  <span style={{ fontSize: '3rem' }}>{getCatEmoji(course.category)}</span>
                </div>
                <span className="card-category-tag">{course.category}</span>
              </div>
              <div className="card-body">
                <div className="card-name">{course.courseTitle}</div>
                <div className="card-instructor">👤 {course.instructorName}</div>
                <div className="card-meta">
                  <span className="card-meta-item">⏱ {course.duration}</span>
                  <span className="card-meta-item">📂 {course.category}</span>
                </div>
                <p className="card-desc">{course.description?.slice(0, 90)}{course.description?.length > 90 ? '…' : ''}</p>
                <div className="card-actions">
                  <button className="btn btn-primary btn-sm" onClick={() => enrollCourse(course._id, course.courseTitle)}>
                    🎓 Enroll Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
