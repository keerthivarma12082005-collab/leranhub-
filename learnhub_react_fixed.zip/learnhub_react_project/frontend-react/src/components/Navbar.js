import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  function logout() {
    localStorage.removeItem('lh_user');
    navigate('/');
  }

  const isActive = (path) => location.pathname === path ? 'active' : '';

  return (
    <nav>
      <div className="nav-logo" onClick={() => navigate('/')}>
        <div className="logo-mark">🎓</div>
        <span><span className="brand-v">Learn</span>Hub</span>
      </div>
      <ul className={`nav-links ${open ? 'show' : ''}`}>
        <li><a href="#!" className={isActive('/courses')} onClick={e => { e.preventDefault(); navigate('/courses'); setOpen(false); }}>📚 Courses</a></li>
        <li><a href="#!" className={`nav-cart-btn ${isActive('/enrollments')}`} onClick={e => { e.preventDefault(); navigate('/enrollments'); setOpen(false); }}>📋 My Enrollments</a></li>
        <li><a href="#!" onClick={e => { e.preventDefault(); logout(); setOpen(false); }}>← Logout</a></li>
      </ul>
      <button className="menu-btn" onClick={() => setOpen(o => !o)}>☰</button>
    </nav>
  );
}
