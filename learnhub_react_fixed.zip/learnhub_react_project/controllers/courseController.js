const Course = require('../models/Course');

// Fallback courses shown when the database is empty (great for demos)
const SAMPLE_COURSES = [
  {
    _id: "sample-1",
    courseTitle: "Full-Stack Web Development Bootcamp",
    description: "Master HTML, CSS, JavaScript, React, Node.js and MongoDB in one comprehensive bootcamp. Build 10 real-world projects and deploy them to the cloud.",
    instructorName: "Sarah Mitchell",
    category: "Web Development",
    duration: "48 hours"
  },
  {
    _id: "sample-2",
    courseTitle: "React & Next.js – From Zero to Pro",
    description: "Learn modern React with hooks, context, and Next.js 14 App Router. Cover SSR, SSG, API routes, and deploy production-ready apps on Vercel.",
    instructorName: "James Okafor",
    category: "Web Development",
    duration: "32 hours"
  },
  {
    _id: "sample-3",
    courseTitle: "Node.js REST API Masterclass",
    description: "Build scalable REST APIs with Express, MongoDB and JWT authentication. Includes rate limiting, file uploads, email sending, and deployment.",
    instructorName: "Priya Sharma",
    category: "Web Development",
    duration: "20 hours"
  },
  {
    _id: "sample-4",
    courseTitle: "Python for Data Science & Machine Learning",
    description: "Go from Python basics to training ML models with scikit-learn, pandas, NumPy and Matplotlib. Includes 5 end-to-end data projects with real datasets.",
    instructorName: "Dr. Lena Müller",
    category: "Data Science",
    duration: "40 hours"
  },
  {
    _id: "sample-5",
    courseTitle: "SQL & Database Analytics",
    description: "Master SQL from SELECT basics to advanced window functions, CTEs, and query optimisation. Analyse real business datasets and build interactive dashboards.",
    instructorName: "Carlos Mendes",
    category: "Data Science",
    duration: "18 hours"
  },
  {
    _id: "sample-6",
    courseTitle: "Deep Learning with TensorFlow",
    description: "Build CNNs, RNNs, and Transformer models using TensorFlow & Keras. Train image classifiers, sentiment analysers, and fine-tune large language models.",
    instructorName: "Dr. Aiko Tanaka",
    category: "Data Science",
    duration: "35 hours"
  },
  {
    _id: "sample-7",
    courseTitle: "UI/UX Design with Figma",
    description: "Learn user research, wireframing, prototyping, and design systems in Figma. Create polished app mockups and conduct usability tests with real users.",
    instructorName: "Isabella Rossi",
    category: "Design",
    duration: "22 hours"
  },
  {
    _id: "sample-8",
    courseTitle: "Motion Design & After Effects",
    description: "Create stunning motion graphics, animated logos, and video intros using Adobe After Effects. Covers keyframing, expressions, and 3D camera techniques.",
    instructorName: "Marcus Lee",
    category: "Design",
    duration: "25 hours"
  },
  {
    _id: "sample-9",
    courseTitle: "Product Management Fundamentals",
    description: "Learn how top PMs define strategy, write PRDs, prioritise backlogs, and ship features. Includes frameworks like RICE, OKRs, and Jobs-to-be-Done.",
    instructorName: "Natalie Chen",
    category: "Business",
    duration: "16 hours"
  },
  {
    _id: "sample-10",
    courseTitle: "Financial Modelling & Valuation",
    description: "Build DCF, LBO, and comparable-company models in Excel from scratch. Master corporate finance concepts used by investment bankers and analysts.",
    instructorName: "David Osei",
    category: "Business",
    duration: "28 hours"
  },
  {
    _id: "sample-11",
    courseTitle: "Digital Marketing & SEO Masterclass",
    description: "Grow traffic and conversions with proven SEO, Google Ads, Facebook Ads, and email marketing strategies. Includes real campaign walkthroughs and analytics.",
    instructorName: "Sophie Laurent",
    category: "Marketing",
    duration: "24 hours"
  },
  {
    _id: "sample-12",
    courseTitle: "Content Marketing & Brand Storytelling",
    description: "Craft compelling brand narratives and content strategies that attract, engage, and retain customers. Covers blogs, video scripts, social media and newsletters.",
    instructorName: "Raj Patel",
    category: "Marketing",
    duration: "14 hours"
  }
];

exports.getAllCourses = async (req, res) => {
    const courses = await Course.find();
    // If DB is empty, serve sample courses so the UI is never blank
    res.json(courses.length > 0 ? courses : SAMPLE_COURSES);
};

exports.getCourseById = async (req, res) => {
    const course = await Course.findById(req.params.id);
    res.json(course);
};

exports.createCourse = async (req, res) => {
    const course = await Course.create(req.body);
    res.json(course);
};

exports.updateCourse = async (req, res) => {
    const course = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(course);
};

exports.deleteCourse = async (req, res) => {
    await Course.findByIdAndDelete(req.params.id);
    res.json({ message: "Course Deleted" });
};
