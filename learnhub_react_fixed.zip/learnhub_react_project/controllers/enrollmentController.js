const Enrollment = require('../models/Enrollment');

exports.getAllEnrollments = async(req,res)=>{

    const enrollments = await Enrollment.find();

    res.json(enrollments);

}


exports.getEnrollmentById = async(req,res)=>{

    const enrollment = await Enrollment.findById(
        req.params.id
    );

    res.json(enrollment);

}


exports.createEnrollment = async(req,res)=>{

    const enrollment = await Enrollment.create(
        req.body
    );

    res.json(enrollment);

}


exports.updateEnrollment = async(req,res)=>{

    const enrollment =
    await Enrollment.findByIdAndUpdate(

        req.params.id,

        req.body,

        {new:true}

    );

    res.json(enrollment);

}


exports.deleteEnrollment = async(req,res)=>{

    await Enrollment.findByIdAndDelete(
        req.params.id
    );

    res.json({

        message:"Enrollment Deleted"

    });

}