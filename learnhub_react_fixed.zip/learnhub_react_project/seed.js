// Run this once to populate your MongoDB with sample courses:
//   node seed.js

const mongoose = require('mongoose');
const Course = require('./models/Course');
require('./connection');

const courses = [
  // ── Web Development ──────────────────────────────────────────
  {
    courseTitle: "Full-Stack Web Development Bootcamp",
    description: "Master HTML, CSS, JavaScript, React, Node.js and MongoDB in one comprehensive bootcamp. Build 10 real-world projects and deploy them to the cloud.",
    instructorName: "Sarah Mitchell",
    category: "Web Development",
    duration: "48 hours"
  },
  {
    courseTitle: "React & Next.js – From Zero to Pro",
    description: "Learn modern React with hooks, context, and Next.js 14 App Router. Cover SSR, SSG, API routes, and deploy production-ready apps on Vercel.",
    instructorName: "James Okafor",
    category: "Web Development",
    duration: "32 hours"
  },
  {
    courseTitle: "Node.js REST API Masterclass",
    description: "Build scalable REST APIs with Express, MongoDB and JWT authentication. Includes rate limiting, file uploads, email sending, and deployment on Railway.",
    instructorName: "Priya Sharma",
    category: "Web Development",
    duration: "20 hours"
  },

  // ── Data Science ─────────────────────────────────────────────
  {
    courseTitle: "Python for Data Science & Machine Learning",
    description: "Go from Python basics to training ML models with scikit-learn, pandas, NumPy and Matplotlib. Includes 5 end-to-end data projects with real datasets.",
    instructorName: "Dr. Lena Müller",
    category: "Data Science",
    duration: "40 hours"
  },
  {
    courseTitle: "SQL & Database Analytics",
    description: "Master SQL from SELECT basics to advanced window functions, CTEs, and query optimisation. Analyse real business datasets and build interactive dashboards.",
    instructorName: "Carlos Mendes",
    category: "Data Science",
    duration: "18 hours"
  },
  {
    courseTitle: "Deep Learning with TensorFlow",
    description: "Build CNNs, RNNs, and Transformer models using TensorFlow & Keras. Train image classifiers, sentiment analysers, and fine-tune large language models.",
    instructorName: "Dr. Aiko Tanaka",
    category: "Data Science",
    duration: "35 hours"
  },

  // ── Design ───────────────────────────────────────────────────
  {
    courseTitle: "UI/UX Design with Figma",
    description: "Learn user research, wireframing, prototyping, and design systems in Figma. Create polished app mockups and conduct usability tests with real users.",
    instructorName: "Isabella Rossi",
    category: "Design",
    duration: "22 hours"
  },
  {
    courseTitle: "Motion Design & After Effects",
    description: "Create stunning motion graphics, animated logos, and video intros using Adobe After Effects. Covers keyframing, expressions, and 3D camera techniques.",
    instructorName: "Marcus Lee",
    category: "Design",
    duration: "25 hours"
  },

  // ── Business ─────────────────────────────────────────────────
  {
    courseTitle: "Product Management Fundamentals",
    description: "Learn how top PMs define strategy, write PRDs, prioritise backlogs, and ship features. Includes frameworks like RICE, OKRs, and Jobs-to-be-Done.",
    instructorName: "Natalie Chen",
    category: "Business",
    duration: "16 hours"
  },
  {
    courseTitle: "Financial Modelling & Valuation",
    description: "Build DCF, LBO, and comparable-company models in Excel from scratch. Master corporate finance concepts used by investment bankers and analysts.",
    instructorName: "David Osei",
    category: "Business",
    duration: "28 hours"
  },

  // ── Marketing ────────────────────────────────────────────────
  {
    courseTitle: "Digital Marketing & SEO Masterclass",
    description: "Grow traffic and conversions with proven SEO, Google Ads, Facebook Ads, and email marketing strategies. Includes real campaign walkthroughs and analytics.",
    instructorName: "Sophie Laurent",
    category: "Marketing",
    duration: "24 hours"
  },
  {
    courseTitle: "Content Marketing & Brand Storytelling",
    description: "Craft compelling brand narratives and content strategies that attract, engage, and retain customers. Covers blogs, video scripts, social media and newsletters.",
    instructorName: "Raj Patel",
    category: "Marketing",
    duration: "14 hours"
  }
];

mongoose.connection.once('open', async () => {
  try {
    await Course.deleteMany({});
    const inserted = await Course.insertMany(courses);
    console.log(`✅  Seeded ${inserted.length} courses successfully!`);
  } catch (err) {
    console.error('❌  Seed error:', err.message);
  } finally {
    mongoose.connection.close();
  }
});
