const mongoose = require('mongoose');

const enrollmentSchema = new mongoose.Schema({

    learnerName:{
        type:String,
        required:true
    },

    courseId:{
        type:String,
        required:true
    },

    progress:{
        type:Number,
        default:0
    }

});

module.exports = mongoose.model(
    "Enrollment",
    enrollmentSchema
);