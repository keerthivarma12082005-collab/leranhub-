const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({

    courseTitle:{
        type:String,
        required:true
    },

    description:{
        type:String,
        required:true
    },

    instructorName:{
        type:String,
        required:true
    },

    category:{
        type:String,
        required:true
    },

    duration:{
        type:String,
        required:true
    }

});

module.exports = mongoose.model("Course",courseSchema);