# LearnHub — React Edition

## Project Structure

```
learnhub_react_project/
├── frontend-react/        ← React app (your new frontend)
│   ├── src/
│   │   ├── pages/         ← Home, Login, Signup, Courses, Enrollments
│   │   ├── components/    ← Navbar
│   │   ├── App.js         ← Router setup
│   │   ├── ToastContext.js← Toast notifications
│   │   └── index.css      ← Global styles
│   └── package.json
├── controllers/           ← Backend controllers
├── models/                ← MongoDB models
├── routes/                ← Express routes
├── app.js                 ← Backend entry point
├── connection.js          ← MongoDB connection
└── backend-package.json   ← Backend dependencies
```

## How to Run

### 1. Start the Backend
```bash
# From project root
npm install   # (uses backend-package.json — rename it to package.json if needed)
node app.js
# Backend runs on http://localhost:8002
```

### 2. Start the React Frontend
```bash
cd frontend-react
npm install
npm start
# Opens http://localhost:3000
```

## Pages

| Route         | Page        | Auth Required |
|---------------|-------------|---------------|
| `/`           | Home        | No            |
| `/login`      | Login       | No            |
| `/signup`     | Sign Up     | No            |
| `/courses`    | Courses     | Yes           |
| `/enrollments`| Enrollments | Yes           |

## Features
- React Router for SPA navigation (no page reloads)
- Protected routes (redirects to login if not authenticated)
- Toast notification system
- Responsive design (mobile hamburger menu, stacked layouts)
- All original functionality preserved: enroll, track progress, remove enrollment
